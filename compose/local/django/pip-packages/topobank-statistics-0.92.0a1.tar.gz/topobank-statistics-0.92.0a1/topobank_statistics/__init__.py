from .apps import __version__
