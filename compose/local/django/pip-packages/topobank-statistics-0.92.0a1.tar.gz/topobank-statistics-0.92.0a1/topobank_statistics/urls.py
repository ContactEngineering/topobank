from django.urls import re_path
from django.contrib.auth.decorators import login_required


from . import views

app_name = "statistics"
urlpatterns = [
    # Define extra urls here
]
