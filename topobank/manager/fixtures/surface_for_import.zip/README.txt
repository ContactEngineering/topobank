This file is an example surface for testing purposes.
Please see topobank/manager/tests/test*.py for details.
